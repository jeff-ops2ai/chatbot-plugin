export const SUPABASE_URL = 'https://hgmydjbafgodlgnkjlhs.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhnbXlkamJhZmdvZGxnbmtqbGhzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU4ODMwNjAsImV4cCI6MjA1MTQ1OTA2MH0._vg0aO7TjZvAQAYWUxw4YzdZgeoNaso2vE-k7_GmT8k';

export const DEFAULT_SYSTEM_PROMPT = 'You are a helpful voice assistant that specializes in clear and concise responses.';